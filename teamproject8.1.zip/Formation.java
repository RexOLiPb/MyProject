/**
 * Model the formation
 * @author Dangerous
 */
public class Formation implements TitleFormation
{
	private String title;
	
	public String titleFormat() 
	{	
		title = "*";
		return title;
	}


}
