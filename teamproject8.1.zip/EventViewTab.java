/**
 * EventViewTab of the view: Day, Week, Month, Agenda
 * @author Dangerous
 */
public enum EventViewTab
{
	Day, Week, Month, Agenda
}