/**
 * An interface to format title
 * @author Dangerous
 */
public interface TitleFormation 
{
	public String titleFormat();
}
