package dijkstra;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] weight = { { 0, 50, -1, 80, -1 }, { -1, 0, 60, 90, -1 }, { -1, -1, 0, -1, 40 },
				{ -1, -1, 20, 0, 70 }, { -1, 50, -1, -1, 0 } };
		String[] str = { "A", "B", "C", "D", "E"};
		int len = str.length;
		Dijkstra dijkstra = new Dijkstra(len);

		for (int i = 0; i < str.length; i++) {
			dijkstra.dijkstra(weight, str, i);
		}
	}

}
