package bst;

import java.util.Stack;

public class Bst {
	public Node init() {
		Node J = new Node(8, null, null);
		Node H = new Node(4, null, null);
		Node G = new Node(2, null, null);
		Node F = new Node(7, null, J);
		Node E = new Node(5, H, null);
		Node D = new Node(1, null, G);
		Node C = new Node(9, F, null);
		Node B = new Node(3, D, E);
		Node A = new Node(6, B, C);
		return A; // return root
	}

	public void printNode(Node node) {
		System.out.print(node.getData());
	}

	public void theFirstTraversal(Node root) {
		printNode(root);
		if (root.getLeftNode() != null) {
			theFirstTraversal(root.getLeftNode());
		}
		if (root.getRightNode() != null) {
			theFirstTraversal(root.getRightNode());
		}
	}

	public void theInOrderTraversal(Node root) {
		if (root.getLeftNode() != null) {
			theInOrderTraversal(root.getLeftNode());
		}
		printNode(root);
		if (root.getRightNode() != null) {
			theInOrderTraversal(root.getRightNode());
		}
	}

	public void thePostOrderTraversal(Node root) {
		if (root.getLeftNode() != null) {
			thePostOrderTraversal(root.getLeftNode());
		}
		if (root.getRightNode() != null) {
			thePostOrderTraversal(root.getRightNode());
		}
		printNode(root);
	}
	
	

	
	public String postOrder2(Node root){
		 
        Stack<Node> stack = new Stack<Node>();  
        Stack<Node> output = new Stack<Node>();
        Node node = root;  
        while(node != null || stack.size()>0){  
            if(node != null){  
                output.push(node);  
                stack.push(node);  
                node = node.getRightNode();  
            }else{  
                node = stack.pop();  
                node = node.getLeftNode();  
            }  
        }  
        
	return output.toString();

    }

	
	public int getNumberofNode(Node root) {
		 int nodes = 0;
	        if(root == null)
	            return 0;
	        else{
	            nodes = 1 + getNumberofNode(root.getLeftNode()) + getNumberofNode(root.getRightNode());
	        }
	        return nodes;
	}
	
	public int getTreeDepth(Node root) {

        if(root.getLeftNode() == null && root.getRightNode() == null)
        {
            return 1;
        }
        int left=0,right = 0;
        if(root.getLeftNode()!=null)
        {
            left = getTreeDepth(root.getLeftNode());
        }
        if(root.getRightNode()!=null)
        {
            right = getTreeDepth(root.getRightNode());
        }
        return left>right?left+1:right+1;
    }


	public static void main(String[] args) {
		Bst tree = new Bst();
		Node root = tree.init();
		System.out.println("Preorder: ");
		tree.theFirstTraversal(root);
		System.out.println("");
		System.out.println("Inorder: ");
		tree.theInOrderTraversal(root);
		System.out.println("");
		System.out.println("Postorder: ");
		tree.thePostOrderTraversal(root);
		System.out.println("");
		System.out.println("String for PostOrder in a Stack: "+ tree.postOrder2(root));
		System.out.println("first one will be poped at last and last one will be poped at first");
		System.out.println("So we get: ");
		tree.thePostOrderTraversal(root);
		System.out.println("");
		System.out.println("Height :"+tree.getTreeDepth(root));
		System.out.println("Number of nodes: "+tree.getNumberofNode(root));
		
	}

}
