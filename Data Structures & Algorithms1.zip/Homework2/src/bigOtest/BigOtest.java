package bigOtest;

import java.util.Date;

public class BigOtest {

	public static void main(String[] args) {

		System.out.println("n |Sum A Time A|sum B Time B");
		System.out.println();

		for (long n = 1000; n <= 100000; n = n + 100) {

			Date today = new Date();
			long start = today.getTime();
			long sum = 0;

			for (long i = 1; i <= n; i++) {
				for (long j = 1; j <= 10000; j++) {
					sum = sum + j;}}
			today = new Date();
			long end = today.getTime();
			long TimeSpent1 = end - start;
			System.out.printf("%-7d|%-15d%-7d", n, sum, TimeSpent1);
			

			sum = 0;
			today = new Date();
			start = today.getTime();
			for (long i = 1; i <= n; i++) {
				for (long j = 1; j <= n; j++) {
					sum = sum + j;}}

			today = new Date();
			end = today.getTime();
			long TimeSpent2 = end - start;
			System.out.printf("|%-15d %-7d %n", sum, TimeSpent2);

			if (TimeSpent2 > TimeSpent1) {
				System.out.println("Up to " + n + "Loop B is faster");
				break;
			}

		}
	}
}
