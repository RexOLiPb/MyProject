//Create the class Main which is used for the testing of the operations of class TwoDimensionalBinaryTree.
package twodimensionalbinarytree;

import java.util.NoSuchElementException;

import java.awt.Point;

public class Main {

	// Define the main method of the class. The execution of the program starts
	// here.

	/**
	 * 
	 * A driver to test the methods addPoint and contains of
	 * 
	 * the class TwoDimensionalBinaryTree
	 * 
	 */
	public static void main(String[] args) {

		// create the object of class
		TwoDimensionalBinaryTree<Point> pointTree = new TwoDimensionalBinaryTree<Point>();

		// add the new nodes to the binary search tree
		pointTree.addPoint(new Point(60, 50));
		pointTree.addPoint(new Point(50, 60));
		pointTree.addPoint(new Point(20, 30));
		pointTree.addPoint(new Point(55, 80));
		pointTree.addPoint(new Point(90, 30));
		pointTree.addPoint(new Point(100, 20));
		pointTree.addPoint(new Point(70, 40));

		// print the message
		System.out.println("Number of nodes contained in tree: ");

		if (pointTree.contains(new Point(90, 30)))
			System.out.println("Tree correctly identifiesthat it contains point (90, 30)");
		else
			System.out.println("Tree incorrectly identifies that it doesn't contain point (90,30)");

		// check if the point is contained in the tree
		if (pointTree.contains(new Point(120, 30)))
			System.out.println("Tree incorrectly identifies that it contains point (110, 30)");
		else
			System.out.println("Tree correctly identifies that it doesn't contain point (110, 30)");

		pointTree.draw();
	} // end main method
}// end Main class
/*
 * Sample Output:
 * 
 * Number of nodes contained in the tree: 5
 * 
 * Tree correctly identifies that it contains point (90, 30)
 * 
 * Tree correctly identifies that it doesn't contain point (110, 30)
 * 
 * Output explanation:
 * 
 * In the output it first shows the number of nodes in the two dimensional
 * binary search tree. After that it checks if the node 90, 30) present in the
 * tree which is correctly identified. Again it checks if (110, 30) is contained
 * in the tree which is again identified correctly that it does not contain the
 * node.
 */