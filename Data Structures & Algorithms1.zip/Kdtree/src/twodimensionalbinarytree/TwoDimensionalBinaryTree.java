package twodimensionalbinarytree;

import java.util.NoSuchElementException;
import java.awt.Point;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class TwoDimensionalBinaryTree<T extends Point> {

	private BinaryNode<T> root;

	public TwoDimensionalBinaryTree() {
		root = null;
	}

	public TwoDimensionalBinaryTree(T rootData) {
		root = new BinaryNode<T>(rootData);
	}

	public TwoDimensionalBinaryTree(T rootData, TwoDimensionalBinaryTree<T> leftTree,
			TwoDimensionalBinaryTree<T> rightTree) {
		privateSetTree(rootData, leftTree, rightTree);
	}

	public void setTree(T rootData) {
		root = new BinaryNode<T>(rootData);
	}

	public void setTree(T rootData, TwoDimensionalBinaryTree<T> leftTree, TwoDimensionalBinaryTree<T> rightTree) {
		privateSetTree(rootData, leftTree, rightTree);
	}

	public void addPoint(T anEntry) {
		int layer = 0;
		BinaryNode<T> currentNode = getRootNode();
		if (currentNode == null) {
			setRootNode(new BinaryNode<T>(anEntry, null, null));
		} else {
			boolean positionFound = false;
			while (positionFound != true) {
				if (layer % 2 == 0) {
					if (anEntry.getX() > currentNode.getData().getX()) {
						if (currentNode.getRightChild() != null)
							currentNode = currentNode.getRightChild();
						else {
							BinaryNode<T> tempNode = new BinaryNode<T>(anEntry, null, null);
							currentNode.setRightChild(tempNode);
							positionFound = true;
						}
					} else {
						if (currentNode.getLeftChild() != null)
							currentNode = currentNode.getLeftChild();
						else {
							BinaryNode<T> tempNode = new BinaryNode<T>(anEntry, null, null);
							currentNode.setLeftChild(tempNode);
							positionFound = true;
						}
					}
					layer++;
				} else {
					if (anEntry.getY() > currentNode.getData().getY()) {
						if (currentNode.getRightChild() != null)
							currentNode = currentNode.getRightChild();
						else {
							BinaryNode<T> tempNode = new BinaryNode<T>(anEntry, null, null);
							currentNode.setRightChild(tempNode);
							positionFound = true;
						}
					} else {
						if (currentNode.getLeftChild() != null)
							currentNode = currentNode.getLeftChild();
						else {
							BinaryNode<T> tempNode = new BinaryNode<T>(anEntry, null, null);
							currentNode.setLeftChild(tempNode);
							positionFound = true;
						}
					}
					layer++;
				}
			} // end while
		}
	} // end addPoint

	public boolean contains(T anEntry) {
		int layer = 0;
		BinaryNode<T> currentNode = getRootNode();
		boolean found = false;

		while (found == false && currentNode != null) {
			if (currentNode.getData().equals(anEntry)) {
				found = true;
				break;
			}

			if (layer % 2 == 0) {
				if (anEntry.getX() > currentNode.getData().getX()) {
					currentNode = currentNode.getRightChild();
				} else {
					currentNode = currentNode.getLeftChild();
				}
				layer++;
			} else {
				if (anEntry.getY() > currentNode.getData().getY()) {
					currentNode = currentNode.getRightChild();
				} else {
					currentNode = currentNode.getLeftChild();
				}
				layer++;
			}
		} // end while
		return found;
	} // end contains

	public void draw() {
		Rect r = new Rect();
		r.drawRect();
	}

	private void privateSetTree(T rootData, TwoDimensionalBinaryTree<T> leftTree,
			TwoDimensionalBinaryTree<T> rightTree) {
		root = new BinaryNode<T>(rootData);

		if ((leftTree != null) && !leftTree.isEmpty())
			root.setLeftChild(leftTree.root);
		if ((rightTree != null) && !rightTree.isEmpty()) {
			if (rightTree != leftTree)
				root.setRightChild(rightTree.root);
			else
				root.setRightChild(rightTree.root.copy());
		} // end if
		if ((leftTree != null) && (leftTree != this))
			leftTree.clear();
		if ((rightTree != null) && (rightTree != this))
			rightTree.clear();
	} // end privateSetTree

	private BinaryNode<T> copyNodes() {
		return (BinaryNode<T>) root.copy();
	} // end copyNodes

	public T getRootData() {
		T rootData = null;
		if (root != null)
			rootData = root.getData();
		return rootData;
	} // end getRootData

	public boolean isEmpty() {
		return root == null;
	} // end isEmpty

	public void clear() {
		root = null;
	} // end clear

	protected void setRootData(T rootData) {
		root.setData(rootData);
	} // end setRootData

	protected void setRootNode(BinaryNode<T> rootNode) {
		root = rootNode;
	} // end setRootNode

	protected BinaryNode<T> getRootNode() {
		return root;
	} // end getRootNode

	private class BinaryNode<T extends Point> {
		private T data;
		private BinaryNode<T> left;
		private BinaryNode<T> right;

		public BinaryNode(T data, BinaryNode<T> left, BinaryNode<T> right) {
			this.data = data;
			this.left = left;
			this.left = right;
		}

		public BinaryNode(T data) {
			this(data, null, null);
		}

		public T getData() {
			return data;
		}

		public void setData(T newData) {
			data = newData;
		}

		public BinaryNode<T> getLeftChild() {
			return left;
		}

		public void setLeftChild(BinaryNode<T> left) {
			this.left = left;
		}

		public BinaryNode<T> getRightChild() {
			return right;
		}

		public void setRightChild(BinaryNode<T> right) {
			this.right = right;
		}

		public BinaryNode<T> copy() {
			BinaryNode<T> root = new BinaryNode<T>(data, null, null);

			if (left != null) // If there's a left subtree
				root.left = left.copy(); // Duplicate; attach
			if (right != null) // If there's a right subtree
				root.right = right.copy(); // Duplicate; attach
			return root; // Return resulting tree
		}
	}

	private class Rect extends JPanel {
		JFrame frame;
		Rectangle rec;

		public Rect() {
			rec = new Rectangle(100, 200, 50, 75);
		}

		public void drawRect() {
			frame = new JFrame();
			frame.setVisible(true);
			frame.setSize(600, 600);
			;
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.add(this);
		}

		public void paintComponent(Graphics g) {
			int x = 50;
			int y = 50;
			int width = 150;
			int height = 150;
			BinaryNode<T> currentNode = root;
			int currentX, currentY, currentLeftX, currentLeftY, currentRightX, currentRightY;
			currentX = (int) currentNode.getData().getX();
			currentY = (int) currentNode.getData().getY();
			currentLeftX = (int) currentNode.getLeftChild().getData().getX();
			currentLeftY = (int) currentNode.getLeftChild().getData().getY();
			currentRightX = (int) currentNode.getRightChild().getData().getX();
			currentRightY = (int) currentNode.getRightChild().getData().getY();

			g.setColor(Color.blue);
			g.drawRect(x, y, width, height);

			g.setColor(Color.red);

			// the following draws a vertical line at top coordinate 50, 50 and bottom
			// coordinate 100,200
			g.drawLine(currentX + x, y, currentX + x, height + y);
			// g.drawLine(100, 100, 100, 200);
			g.setColor(Color.black);
			g.fillOval(currentX + x - 2, currentY + y - 2, 4, 4);
			g.fillOval(currentLeftX + x - 2, currentLeftY + y - 2, 4, 4);
			g.fillOval(currentRightX + x - 2, currentRightY + y - 2, 4, 4);

			g.setColor(Color.green);
			// the following is a horizontal line
			g.drawLine(x, currentLeftY + y, currentX + x, currentLeftY + y);
			g.drawLine(currentX + x, currentRightY + y, width + x, currentRightY + y);
			if (currentNode.getLeftChild() != null)
				paintComponentHelper1(g, currentNode.getLeftChild());
			if (currentNode.getRightChild() != null)
				paintComponentHelper2(g, currentNode.getRightChild());
		}

		public void paintComponentHelper1(Graphics g, BinaryNode<T> currentNode) {
			int x = 50;
			int y = 50;
			int width = 150;
			int height = 150;
			int currentX, currentY, currentLeftX, currentLeftY, currentRightX, currentRightY;
			currentX = (int) currentNode.getData().getX();
			currentY = (int) currentNode.getData().getY();

			if (currentNode.getLeftChild() != null) {
				currentLeftX = (int) currentNode.getLeftChild().getData().getX();
				currentLeftY = (int) currentNode.getLeftChild().getData().getY();
				g.setColor(Color.blue);
				if (currentX < currentLeftX)
					g.drawLine(currentLeftX + x, currentY + y, currentLeftX + x, height + y);
				else
					g.drawLine(currentLeftX + x, y, currentLeftX + x, currentY + y);
				g.setColor(Color.black);
				g.fillOval(currentLeftX + x - 2, currentLeftY + y - 2, 4, 4);
			}
			if (currentNode.getRightChild() != null) {
				currentRightX = (int) currentNode.getRightChild().getData().getX();
				currentRightY = (int) currentNode.getRightChild().getData().getY();
				g.setColor(Color.blue);
				if (currentX < currentRightX)
					g.drawLine(currentRightX + x, currentY + y, currentRightX + x, height + y);
				else
					g.drawLine(currentRightX + x, y, currentRightX + x, currentY + y);
				g.setColor(Color.black);
				g.fillOval(currentRightX + x - 2, currentRightY + y - 2, 4, 4);
			}
			if (currentNode.getLeftChild() != null)
				paintComponentHelper1(g, currentNode.getLeftChild());
			if (currentNode.getRightChild() != null)
				paintComponentHelper2(g, currentNode.getRightChild());
		}

		public void paintComponentHelper2(Graphics g, BinaryNode<T> currentNode) {
			int x = 50;
			int y = 50;
			int width = 150;
			int height = 150;
			int currentX, currentY, currentLeftX, currentLeftY, currentRightX, currentRightY;
			currentX = (int) currentNode.getData().getX();
			currentY = (int) currentNode.getData().getY();

			if (currentNode.getLeftChild() != null) {
				currentLeftX = (int) currentNode.getLeftChild().getData().getX();
				currentLeftY = (int) currentNode.getLeftChild().getData().getY();
				g.setColor(Color.blue);
				if (currentX < currentLeftX)
					g.drawLine(currentLeftX + x, y, currentLeftX + x, currentY + y);
				else
					g.drawLine(currentLeftX + x, currentY + y, currentLeftX + x, height + y);

				g.setColor(Color.black);
				g.fillOval(currentLeftX + x - 2, currentLeftY + y - 2, 4, 4);
			}
			if (currentNode.getRightChild() != null) {
				currentRightX = (int) currentNode.getRightChild().getData().getX();
				currentRightY = (int) currentNode.getRightChild().getData().getY();
				g.setColor(Color.blue);
				if (currentX < currentRightX)
					g.drawLine(currentRightX + x, y, currentRightX + x, currentY + y);
				else
					g.drawLine(currentRightX + x, currentY + y, currentRightX + x, height + y);

				g.setColor(Color.black);
				g.fillOval(currentRightX + x - 2, currentRightY + y - 2, 4, 4);
			}
			if (currentNode.getLeftChild() != null)
				paintComponentHelper1(g, currentNode.getLeftChild());
			if (currentNode.getRightChild() != null)
				paintComponentHelper2(g, currentNode.getRightChild());
		}
	}
}
