package intopost;

import java.io.IOException;

public class IntoPost {
	
	public String convertTopostfix(String infix) {
		Stack operatorStack;
		String postfix = ""; 
		int Size = infix.length();
		operatorStack = new Stack(Size);
		int i = 0;
		while (i < Size) {
			char ch = infix.charAt(i);
			switch (ch) {
			case '^':
				operatorStack.push(ch);
				break;
			case '+':
			case '-':
			case '*':
			case '/':
				while (!operatorStack.isEmpty()) {
					char top = operatorStack.pop();
					int prec1 = precedenceLevel(ch);
					if (top == '(') {
						operatorStack.push(top);
						break;
					} else {
						int prec2;

						if (top == '+' || top == '-')
							prec2 = 0;
						else
							prec2 = 1;
						if (prec2 < prec1) {
							operatorStack.push(top);
							break;
						} else
							postfix = postfix + top;
					}
				}
				operatorStack.push(ch);
				break;
			case '(':
				operatorStack.push(ch);
				break;
			case ')':
				char topChar = operatorStack.pop();
				while (!operatorStack.isEmpty() && topChar != '(') {
					postfix = postfix + topChar;
					topChar = operatorStack.pop();
				}
				break;
			default:
				postfix = postfix + ch;
				break;

			}
			i++;
		}
		while (!operatorStack.isEmpty()) {
			char topChar = operatorStack.pop();
			postfix = postfix + topChar;
		}

		return postfix;
	}

	int precedenceLevel(char op) {
		switch (op) {
		case '+':
		case '-':
			return 0;
		case '*':
		case '/':
			return 1;
		default:
			throw new IllegalArgumentException("Operator unknown: " + op);
		}
	}

	public static void main(String[] args) throws IOException {
		String input = "(6*6-1)/5+2*(13+14)-52^0";
		String postfix;
		IntoPost theTrans = new IntoPost();
		postfix = theTrans.convertTopostfix(input);
		System.out.println("input: (6*6-1)/5+2*(13+14)-52^0, its postfix is " + postfix + '\n');
	}

	class Stack {
		private int maxSize;
		private char[] stackArray;
		private int top;

		public Stack(int max) {
			maxSize = max;
			stackArray = new char[maxSize];
			top = -1;
		}

		public void push(char j) {
			stackArray[++top] = j;
		}
		public char pop() {
			return stackArray[top--];
		}
		public char peek() {
			return stackArray[top];
		}
		public boolean isEmpty() {
			return (top == -1);
		}
	}
}
