package linkstack;

public interface StackInterface<T> {

}
