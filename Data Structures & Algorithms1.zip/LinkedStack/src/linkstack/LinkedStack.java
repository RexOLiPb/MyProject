package linkstack;

public class LinkedStack<T> implements StackInterface<T> {
	private Node firstNode; 

	public LinkedStack() {
		firstNode = null;
	} 

	public void push(T newEntry) {
		Node newNode = new Node(newEntry, firstNode);
		firstNode = newNode;
	} 

	public T peek() {
		T top = null;
		if (firstNode != null)
			top = firstNode.getData();
		return top;
	} 
	public T pop() {
		T top = peek();
		if (firstNode != null)
			firstNode = firstNode.getNextNode();
		return top;
	} 

	public boolean isEmpty() {
		return firstNode == null;
	} 

	private class Node {
		private T data; 
		private Node next; 

		private Node(T dataPortion) {
			data = dataPortion;
			next = null;
		} 

		private Node(T dataPortion, Node linkPortion) {
			data = dataPortion;
			next = linkPortion;
		} 

		private T getData() {
			return data;
		} 

		private Node getNextNode() {
			return next;
		} 
	} 
	public static void main(String[] args) {
		LinkedStack<Integer> stack = new LinkedStack<>();
		stack.push(4);
		stack.push(1);
		stack.push(3);
		stack.push(1);
		stack.push(0);
		stack.push(2);
		stack.push(5);
		stack.push(1);
		stack.push(6);
		stack.push(6);
		System.out.println("Check if stack is empty? " + stack.isEmpty());
		System.out.println("first element in the stack : " + stack.peek());
		System.out.print("Removing and showing all the elements in the stack one by one : ");
		while (!stack.isEmpty()) {
			System.out.print(stack.pop() + " ");
		}
		System.out.println("\nis stack empty after removing all eleemnts now? " + stack.isEmpty());
	}
}
