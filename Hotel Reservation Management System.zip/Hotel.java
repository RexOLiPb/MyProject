/**
 * Hotel Reservation System
 * CS157A Group Project
 * @version 1.00
 */

public class Hotel {
	
	public static void main(String args[]) {
		View view = new View(new Model());
	}
}